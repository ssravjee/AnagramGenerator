package com.puzzles;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

import com.io.FileReader;

public class AnagramGenerator {
	private static final String INPUT_FILE = "input_words.txt";
	private static final String OUTPUT_FILE = "output_words.txt";
	
	public static void main(String[] args) throws IOException {
		System.out.println("Program Started....");
		AnagramGenerator generator = new AnagramGenerator();
		System.out.println("Attemting to read input file : " + INPUT_FILE);
		List<String> words = generator.readInputFile(INPUT_FILE);
		System.out.println("Input file read successfully");
		System.out.println("Generating anagrams please wait... ");
		HashMap<String, List<String>> writeMap = generator
				.generateAnagrams(words);
		System.out.println("Anagrams generated successfully ");
		com.io.FileWriter fWriter = new com.io.FileWriter();
		System.out.println("Attempting to write anagrams to ouput file : " + OUTPUT_FILE);
		fWriter.writeWords(OUTPUT_FILE, writeMap);
		System.out.println("Writing anagrams to ouput file : " + OUTPUT_FILE + " completed successfully.");
	}

	/**
	 * @param words
	 * @return
	 * @throws MalformedURLException
	 * @throws IOException
	 */
	public HashMap<String, List<String>> generateAnagrams(List<String> words)
			throws MalformedURLException, IOException {
		URL url = new URL("http://codekata.com/data/wordlist.txt");
		// load the dictionary into sc object
		Scanner sc = new Scanner(url.openStream());

		HashMap<String, ArrayList<String>> map = new HashMap<String, ArrayList<String>>();

		while (sc.hasNextLine()) {
			String word = sc.nextLine();
			String sortedWord = sortString(word); // this is a key
			ArrayList<String> anagrams = map.get(sortedWord); // this is a value

			if (anagrams == null)
				anagrams = new ArrayList<String>();
			anagrams.add(word);
			map.put(sortedWord, anagrams);
		}
		HashMap<String, List<String>> writeMap = new HashMap<String, List<String>>();
		List<String> anagrams = null;
		for (int i = 0; i < words.size(); i++) {
			anagrams = map.get(sortString(words.get(i))); // testing
			writeMap.put(words.get(i), anagrams);
		}
		sc.close();
		return writeMap;
	}

	/**
	 * @return
	 */
	public List<String> readInputFile(String fileName) {
		// read input_word.txt
		FileReader f = new FileReader();
		List<String> words = f.getWords(fileName);
		return words;
	}

	private static String sortString(String w) {
		char[] ch = w.toCharArray();
		Arrays.sort(ch);
		return new String(ch);
	}
}